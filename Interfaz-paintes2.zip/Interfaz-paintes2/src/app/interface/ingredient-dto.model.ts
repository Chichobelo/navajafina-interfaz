export interface IngredientDTO {
    nombre: number; 
    name: string;
    cantidad: number; 
    unidad: string; 
  }
  