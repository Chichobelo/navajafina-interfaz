export interface Location {
    idlocation?: number;
    name?: string;
    description?: string;
    address?: string;
    headquarters?: string;
  }