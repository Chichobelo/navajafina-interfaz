export interface LoginRequest {
    username: string; // Nombre de usuario
    password: string; // Contraseña
  }
  