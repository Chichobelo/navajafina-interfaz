export interface PackagingType {
    idpackagingType: number; 
    name: string;            
  }
  