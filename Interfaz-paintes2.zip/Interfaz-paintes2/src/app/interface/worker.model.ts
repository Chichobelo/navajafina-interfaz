export interface Worker {
  idworker?: number;
  name: string;
  username: string;
  password: string;
  position: string;
}