export interface AuthResponse {
    token: string;     // Token JWT devuelto por el backend
    role:string;
  }
  